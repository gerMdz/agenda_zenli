# Kit de contexto Codex — Zenli

Este paquete NO es una aplicación Symfony funcional. Es documentación consolidada y una copia de las migraciones Doctrine v2 previamente preparadas, aún no probadas.

## Uso

1. Descomprimir en la raíz de un repositorio nuevo de Zenli (o copiar `AGENTS.md`, `docs/` y, previa revisión, `migrations/`).
2. Abrir terminal en la raíz y ejecutar `codex`.
3. Pedir: «Leé AGENTS.md y docs/. Revisá las migraciones existentes, detectá inconsistencias y proponé un plan de implementación sin inventar requisitos pendientes».
4. No ejecutar migraciones contra una base con datos reales sin revisarlas y probarlas en una base de desarrollo.

Las migraciones se copiaron tal como estaban; no fueron corregidas silenciosamente. El archivo `docs/pendientes.md` contiene decisiones que deben confirmarse.
